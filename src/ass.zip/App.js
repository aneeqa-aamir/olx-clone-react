import Router from "./Config/Router";
import "./App.css";
import Header from './view/Header'
import Footer from "./view/Footer";

function App() {
  return (
    <div className="App">
      <div>
       {/* <Header/> */}
      </div>

      <Router />

      <div>
        {/* <Footer/> */}
      </div>
    </div>
  );
}

export default App;
