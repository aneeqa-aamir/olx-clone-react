import React from 'react';
import './App.css'; // Import your stylesheet
import Login from '../Login';
// import sellform from '../Login';
import { useNavigate } from 'react-router-dom';

function Header() {
  const navigate = useNavigate()
  return (
    <div className="olx-header">
      <div className="olx-header-container">
        <div className="olx-logo" onClick={() => navigate('/')} >
          <img
            src="https://www.liblogo.com/img-logo/ol8430f3c1-olx-logo-file-olx-new-logo-png-wikimedia-commons.png"
            alt="OLX Logo"
          />
        </div>
        <div className="olx-search">
          <input type="text" placeholder="Search for items, brands, and categories" />
          {/* <button type="button">Search</button> */}
        </div>
        <div className="olx-actions">
          <button className='login' type="button" onClick={() => navigate('/login')} >Login</button>
          <button className='sell' type="button" onClick={() => navigate('/sellform')} >+ Sell</button>
        </div>
      </div>
    </div>
  );
}


export default Header;
