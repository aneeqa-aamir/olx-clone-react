import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Dashboard from "../view/Dashboard";
import Detail from "../view/Detail";
import Register from "../view/Register";
import Login from "../view/Login";
import Sellform from "../view/Sellform/index";

const router = createBrowserRouter([
  { path: "/",
   element: <Register /> },

  { path: "/sellform",
   element: <Sellform /> },
  //
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/dashboard",
    element: <Dashboard />,
  },
  {
    path: "/detail/:adId",
    element: <Detail />,
  },
]);

function Router() {
  return <RouterProvider router={router} />;
}

export default Router;
