// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { getFirestore ,  collection, addDoc  } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDxVWHAM-Ektg2E1yMIvNdrexvmDadS_So",
  authDomain: "olxcom-65113.firebaseapp.com",
  projectId: "olxcom-65113",
  storageBucket: "olxcom-65113.appspot.com",
  messagingSenderId: "117289121303",
  appId: "1:117289121303:web:e67351fcb486591d4d4e52",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export async function register(userInfo) {
 try{
  const { email, password ,fullName,age} = userInfo;
 await createUserWithEmailAndPassword(auth, email, password)
 // Add a new document with a generated id.
  await addDoc(collection(db, "users"), {
    fullName,
    age,
    email,
    
  });

  // console.log({fullName}+{age})

 alert('successfully registered')
}
catch(e){
    alert(e.message)
}
}

export function login(userInfo) {
    try{
  const { email, password } = userInfo;
 signInWithEmailAndPassword(auth, email, password)

 alert('Login successful')
}
catch(e){
    alert(e.message)
}
}

export async function sellDetail(userInfo) {
  try{
   const { title,description,price} = userInfo;
  
  // Add a new document with a generated id.
   await addDoc(collection(db, "form"), {
    title,
    description,
    price,

    
  });
  alert('uploded')
 
   console.log({title,description,price})
  }
   catch(e){
    (alert (e.message))

   }
  }